# School Map simulation package

This package is generated from the content-addressed DroneDream School Map geometry contract.

## Gazebo Sim

```sh
gz sdf -k model.sdf
gz sdf -k world.sdf
gz sdf -k model.physics.sdf
gz sdf -k world.physics.sdf
gz sim -r world.sdf
```

`world.sdf` embeds the static map model and resolves the relative `meshes/` and `materials/`
assets from this directory. `model.config` also allows the directory to be installed as a
Gazebo model package. `world.physics.sdf` contains the exact same collision primitives without
render visuals for deterministic headless PX4 qualification; the visible desktop run uses
`world.sdf`.

## ROS 2 bridge

The static map does not require ROS to exist in Gazebo. With a compatible ROS 2 and
`ros_gz_bridge` installation, bridge simulation time with:

```sh
ros2 run ros_gz_bridge parameter_bridge --ros-args   -p config_file:="$(pwd)/ros_gz_bridge.yaml"
```

Vehicle, camera, depth, odometry and control topics must be added by the signed Runtime for
the exact PX4 vehicle and sensor pack. This package does not claim that ROS 2 or PX4 mission
execution has been smoke-tested.
